# Hotel Room Booking demo

## Setup

### Static mode

 - Demo is ready to run - unpack it to the web server and open in browser. App stores data on the client-side, no server support or setup required.
 
### PHP and MySQL backend 
 - remove  &lt;script src='./js/mock_backend.js'&gt;&lt;/script&gt; from index.html
 - create mysql database and import dump.sql
 - change connection settings in config.php